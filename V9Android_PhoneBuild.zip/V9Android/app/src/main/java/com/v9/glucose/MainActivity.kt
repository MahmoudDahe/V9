package com.v9.glucose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { V9App() }
    }
}

private data class V9Page(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)
private val pages = listOf(
    V9Page("Overview", Icons.Default.Dashboard), V9Page("Patient", Icons.Default.Favorite),
    V9Page("Devices", Icons.Default.Bluetooth), V9Page("Caregiver", Icons.Default.People),
    V9Page("Medical Team", Icons.Default.MedicalServices), V9Page("Space Research", Icons.Default.RocketLaunch),
    V9Page("Reports", Icons.Default.BarChart), V9Page("Privacy", Icons.Default.Security),
    V9Page("Settings", Icons.Default.Settings)
)

@Composable
private fun V9App() {
    var dark by remember { mutableStateOf(true) }
    var page by remember { mutableStateOf("Overview") }
    var role by remember { mutableStateOf("Patient") }
    var connected by remember { mutableStateOf(false) }
    var consent by remember { mutableStateOf(false) }
    var alerts by remember { mutableStateOf(true) }
    var sharing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Welcome to V9. All readings are demonstration data.") }
    var search by remember { mutableStateOf("") }
    var selectedPatient by remember { mutableStateOf("Demo Patient A") }
    var meal by remember { mutableStateOf("Breakfast") }
    var activity by remember { mutableStateOf("Walking") }
    var emergency by remember { mutableStateOf(false) }

    val bg = if (dark) Color(0xFF101827) else Color(0xFFF1F5F9)
    val surface = if (dark) Color(0xFF1B293B) else Color.White
    val fg = if (dark) Color(0xFFF4F7FB) else Color(0xFF172033)
    val muted = if (dark) Color(0xFFB4C0D0) else Color(0xFF64748B)
    val accent = Color(0xFF38BDF8)

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = accent, background = bg, surface = surface, onSurface = fg) else lightColorScheme(primary = Color(0xFF0369A1), background = bg, surface = surface, onSurface = fg)) {
        Scaffold(containerColor = bg, bottomBar = {
            NavigationBar(containerColor = surface) {
                listOf("Overview", "Patient", "Devices", "Reports", "Settings").forEach { item ->
                    val icon = pages.first { it.title == item }.icon
                    NavigationBarItem(selected = page == item, onClick = { page = item }, icon = { Icon(icon, null) }, label = { Text(item, fontSize = 9.sp) })
                }
            }
        }) { padding ->
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text("V9 SMART GLUCOSE", color = fg, fontSize = 21.sp, fontWeight = FontWeight.Black)
                            Text("CONNECTED HEALTH ECOSYSTEM · 1.0", color = muted, fontSize = 10.sp)
                        }
                        Text(if (dark) "DARK" else "LIGHT", color = accent, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { dark = !dark }.padding(8.dp))
                    }
                }
                item {
                    CardBlock(surface) {
                        Text("EXPERIENCE ROLE", color = muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(role) }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                listOf("Patient", "Caregiver / Follower", "Medical Team", "Astronaut Research").forEach { r -> DropdownMenuItem(text = { Text(r) }, onClick = { role = r; expanded = false }) }
                            }
                        }
                    }
                }
                item { Text(page.uppercase(), color = fg, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                when (page) {
                    "Overview" -> {
                        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("Glucose", "112", "mg/dL · Demo", surface, fg, Modifier.weight(1f)); MetricCard("Heart rate", "76", "BPM · Demo", surface, fg, Modifier.weight(1f)) } }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("CGM", if (connected) "Paired" else "Offline", "Simulated", surface, fg, Modifier.weight(1f)); MetricCard("Consent", if (consent) "Granted" else "Pending", "Demo permission", surface, fg, Modifier.weight(1f)) } }
                        item { CardBlock(surface) { Text("Glucose trend · illustrative", color = fg, fontWeight = FontWeight.Bold); TrendChart(accent); Text("Fictional values only. Not a live measurement.", color = muted, fontSize = 11.sp) } }
                        item { CardBlock(surface) { Text("Ecosystem modules", color = fg, fontWeight = FontWeight.Bold); pages.drop(1).forEach { p -> Text("• ${p.title}", color = muted, modifier = Modifier.fillMaxWidth().clickable { page = p.title }.padding(vertical = 6.dp)) } } }
                    }
                    "Patient" -> {
                        item { CardBlock(surface) { Text("Glucose overview", color = fg, fontWeight = FontWeight.Bold); Text("112 mg/dL", color = accent, fontSize = 32.sp, fontWeight = FontWeight.Black); Text("Demo reading from a compatible CGM source", color = muted, fontSize = 11.sp); TrendChart(accent) } }
                        item { CardBlock(surface) { Text("Daily log", color = fg, fontWeight = FontWeight.Bold); ChoiceField("Meal", meal, listOf("Breakfast", "Lunch", "Dinner", "Snack")) { meal = it }; ChoiceField("Activity", activity, listOf("Walking", "Running", "Resting", "Other")) { activity = it }; Button(onClick = { message = "Demo log saved: $meal / $activity" }, modifier = Modifier.fillMaxWidth()) { Text("Save demo log") } } }
                        item { CardBlock(surface) { Text("Medication reminders", color = fg, fontWeight = FontWeight.Bold); Text("Reminder preview only. Follow your prescribed treatment plan. This app does not calculate doses or change treatment.", color = muted, fontSize = 12.sp); OutlinedButton(onClick = { message = "No real notification was scheduled." }) { Text("Preview reminder") } } }
                    }
                    "Devices" -> {
                        item { CardBlock(surface) { Text("Device Center", color = fg, fontWeight = FontWeight.Bold); Text("Compatible CGM · ${if (connected) "Connected (Demo)" else "Disconnected"}", color = if (connected) Color(0xFF22C55E) else Color(0xFFF59E0B)); Text("The CGM is the glucose source. Watch sensors do not measure glucose.", color = muted, fontSize = 12.sp); Button(onClick = { connected = true; message = "Simulated pairing successful. No physical device connected." }, modifier = Modifier.fillMaxWidth()) { Text("Pair demo device") }; OutlinedButton(onClick = { connected = false; message = "Demo device disconnected." }, modifier = Modifier.fillMaxWidth()) { Text("Disconnect") }; OutlinedButton(onClick = { message = if (connected) "Demo sync completed. No external data imported." else "Pair a demo device first." }, modifier = Modifier.fillMaxWidth()) { Text("Simulate synchronization") } } }
                        item { CardBlock(surface) { Text("Smartwatch preview", color = fg, fontWeight = FontWeight.Bold); Text("112 mg/dL · Demo", color = accent, fontSize = 25.sp); Text("Displays CGM data only; does not independently measure glucose.", color = muted, fontSize = 12.sp) } }
                    }
                    "Caregiver" -> {
                        item { CardBlock(surface) { Text("Caregiver portal", color = fg, fontWeight = FontWeight.Bold); Text(if (consent) "Patient consent enabled (Demo)" else "Awaiting patient consent", color = if (consent) Color(0xFF22C55E) else Color(0xFFF59E0B)); Text("Access requires patient authorization.", color = muted, fontSize = 12.sp); Button(onClick = { message = if (consent) "Caregiver demo view: 112 mg/dL" else "No access. Patient consent required." }, modifier = Modifier.fillMaxWidth()) { Text("View shared demo data") }; SwitchLine("Demo alerts", alerts, { alerts = it }, fg); SwitchLine("Sharing", sharing, { sharing = it }, fg) } }
                    }
                    "Medical Team" -> {
                        item { CardBlock(surface) { Text("Medical Team Dashboard", color = fg, fontWeight = FontWeight.Bold); Text("FUTURE DEVELOPMENT CONCEPT · Fictional profiles", color = accent, fontSize = 10.sp); OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Search demo patient") }, modifier = Modifier.fillMaxWidth()); listOf("Demo Patient A", "Demo Patient B", "Demo Patient C").filter { it.contains(search, true) }.forEach { p -> Text(p, color = fg, modifier = Modifier.fillMaxWidth().clickable { selectedPatient = p; message = "$p selected – fictional profile." }.padding(10.dp)) }; Text("Selected: $selectedPatient", color = accent); Button(onClick = { message = "Demo report preview for $selectedPatient. Not a clinical report." }) { Text("Preview report") } } }
                    }
                    "Space Research" -> {
                        item { CardBlock(surface) { Text("Astronaut Research", color = fg, fontWeight = FontWeight.Bold); Text("RESEARCH CONCEPT ONLY", color = accent, fontSize = 11.sp); Text("Simulated mission interface for studying authorized CGM and wearable data in a space environment.", color = muted); Text("Mission ID: V9-MISSION-001", color = fg); Button(onClick = { message = "Mission simulation started. No real astronaut data collected." }) { Text("Start mission simulation") }; OutlinedButton(onClick = { message = "Mission simulation stopped." }) { Text("Stop mission") } } }
                    }
                    "Reports" -> {
                        item { CardBlock(surface) { Text("Reports & Analytics", color = fg, fontWeight = FontWeight.Bold); TrendChart(accent); Text("Illustrative dataset only. Not for medical decisions.", color = muted, fontSize = 11.sp); Button(onClick = { message = "Demo report preview ready. PDF export is not connected." }) { Text("Preview report") }; OutlinedButton(onClick = { message = "Export is not available in this prototype." }) { Text("Export status") } } }
                    }
                    "Privacy" -> {
                        item { CardBlock(surface) { Text("Privacy & Security", color = fg, fontWeight = FontWeight.Bold); Text("Patient consent", color = fg); SwitchLine("Caregiver consent", consent, { consent = it }, fg); SwitchLine("Caregiver alerts", alerts, { alerts = it }, fg); SwitchLine("Demo data sharing", sharing, { sharing = it }, fg); OutlinedButton(onClick = { consent = false; alerts = false; sharing = false; message = "Demo permissions revoked." }) { Text("Revoke permissions") }; Text("Toggles simulate permissions only; no real account access is changed.", color = muted, fontSize = 11.sp) } }
                    }
                    "Settings" -> {
                        item { CardBlock(surface) { Text("Settings & Profile", color = fg, fontWeight = FontWeight.Bold); Text("Role: $role", color = muted); Text("Appearance", color = fg); Row(verticalAlignment = Alignment.CenterVertically) { Text("Dark mode", color = fg); Spacer(Modifier.weight(1f)); Switch(checked = dark, onCheckedChange = { dark = it }) }; Button(onClick = { message = "Demo settings saved for this session." }) { Text("Save settings") } } }
                        item { CardBlock(surface) { Text("Emergency preview", color = fg, fontWeight = FontWeight.Bold); Text("Does not contact emergency services.", color = muted, fontSize = 12.sp); Button(onClick = { emergency = true }) { Text("Open emergency preview") }; if (emergency) { Text("If this is a real emergency, contact local emergency services or seek immediate medical help.", color = Color(0xFFEF4444)); OutlinedButton(onClick = { emergency = false }) { Text("Close") } } } }
                    }
                }
                item { CardBlock(surface) { Text("System message", color = accent, fontWeight = FontWeight.Bold); Text(message, color = fg, fontSize = 12.sp) } }
                item { Text("V9 DEMO BUILD 1.0 · NOT FOR CLINICAL USE", color = muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
            }
        }
    }
}

@Composable private fun CardBlock(surface: Color, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) }
}

@Composable private fun MetricCard(title: String, value: String, subtitle: String, surface: Color, fg: Color, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) { Text(title, color = fg, fontWeight = FontWeight.SemiBold); Text(value, color = Color(0xFF38BDF8), fontSize = 23.sp, fontWeight = FontWeight.Black); Text(subtitle, color = fg.copy(alpha = .65f), fontSize = 10.sp) } }
}

@Composable private fun TrendChart(accent: Color) {
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val vals = listOf(.38f, .52f, .45f, .66f, .53f, .72f, .57f)
        val pts = vals.mapIndexed { i, v -> Offset(size.width * i / (vals.size - 1), size.height * (1 - v)) }
        for (i in 0 until pts.lastIndex) drawLine(accent, pts[i], pts[i + 1], strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
        pts.forEach { drawCircle(accent, radius = 4.dp.toPx(), center = it) }
    }
}

@Composable private fun ChoiceField(label: String, selected: String, options: List<String>, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("$label: $selected") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelected(option); expanded = false }) } }
    }
}

@Composable private fun SwitchLine(label: String, checked: Boolean, onChecked: (Boolean) -> Unit, fg: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) { Text(label, color = fg); Spacer(Modifier.weight(1f)); Switch(checked = checked, onCheckedChange = onChecked) }
}
