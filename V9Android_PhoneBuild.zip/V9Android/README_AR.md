# V9 Smart Glucose – Android project

هذا مشروع Android أصلي باستخدام Kotlin وJetpack Compose، وليس ملف APK جاهزًا في هذه البيئة.

## ما يتضمنه
- واجهات Overview وPatient وDevices وCaregiver وMedical Team وSpace Research وReports وPrivacy وSettings.
- وضع Dark / Light.
- محاكاة اقتران CGM والمزامنة وفصل الجهاز.
- موافقات تجريبية للمتابعين، وسجلات يومية، ورسوم توضيحية، ومعاينة طوارئ.
- بيانات وهمية مع تنبيه واضح أنها ليست بيانات طبية حقيقية.

## بناء APK
1. افتح مجلد `V9Android` في Android Studio (يفضل إصدار حديث يدعم AGP 8.7.3).
2. اسمح بمزامنة Gradle وتنزيل الاعتماديات.
3. من القائمة اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
4. ملف APK التجريبي يظهر عادة في `app/build/outputs/apk/debug/app-debug.apk`.

أو من الطرفية بعد تثبيت Android SDK وGradle:
`gradle assembleDebug`

## حدود الإصدار
- لا يوجد Backend أو تسجيل حساب حقيقي أو تخزين سحابي.
- لا يوجد اتصال فعلي بأجهزة CGM أو Bluetooth؛ الاقتران والمزامنة محاكاة فقط.
- لا توجد إشعارات طبية فعلية أو تصدير PDF.
- الساعة لا تقيس الجلوكوز؛ يمكنها عرض بيانات واردة من CGM متوافق فقط.
- لا يقدم التطبيق تشخيصًا أو جرعات دواء أو إنسولين أو تغييرات علاجية.

هذا إصدار Prototype تجريبي وليس منتجًا طبيًا معتمدًا.
